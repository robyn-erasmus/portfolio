<div class="skills-holder">
    <?php echo $this->content($settings['items']);?> 
</div>

