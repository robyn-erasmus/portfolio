<ul class="timeline-holder global-background-color">
    <?php echo $this->content($settings['items']);?> 
</ul>

